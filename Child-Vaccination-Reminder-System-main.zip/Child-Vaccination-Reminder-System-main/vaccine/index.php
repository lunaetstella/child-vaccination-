<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Child Vaccination System</title>

    <style>
        body
        {
            background-image: url(image/bg.jpg);
            background-repeat: no-repeat;
            background-size: 100vw 100vh;
        }
    </style>
</head>
<body>
    <?php
        include("header1.php");
    ?>
    <h1 class="text-center text-white" style="font-family: cursive;text-shadow: 3px 3px #FF0000;font-size:70px;font-weight:700;margin-top:150px;">Child Vaccination System</h1>

    <center>
    <a href="login.php" class="btn btn-danger text-center mt-5">Check Next Vaccination For Your Child</a>
    </center>
    
</body>
</html>